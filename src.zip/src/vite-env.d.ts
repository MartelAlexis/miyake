/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_DATA_SOURCE?: 'local' | 'api'
  readonly VITE_API_URL?: string
}
interface ImportMeta { readonly env: ImportMetaEnv }
